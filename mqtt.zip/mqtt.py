#!/usr/bin/env python3
import serial, time, re

PORT = "/dev/ttyUSB2"
BAUD = 115200
APN = "internet.lguplus.co.kr"
BROKER = "broker.hivemq.com"
TOPIC = "EG25G-Ceyhun"
PAYLOAD = "hi from pi4 -Ceyhun"

def send_at(ser, cmd, wait="OK", timeout=5):
    ser.write((cmd + "\r\n").encode())
    ser.flush()
    t0 = time.time()
    buf = ""
    while time.time() - t0 < timeout:
        if ser.in_waiting:
            line = ser.readline().decode(errors="ignore").strip()
            print(line)
            buf += line + "\n"
            if wait and wait in line:
                return buf
    return buf

with serial.Serial(PORT, BAUD, timeout=1) as ser:
    # Modem init (done only once)
    send_at(ser, "AT")
    send_at(ser, "ATE0")  # disable echo
    send_at(ser, "AT+CMEE=2")
    send_at(ser, f'AT+CGDCONT=1,"IP","{APN}"')
    send_at(ser, "AT+CFUN=1")
    send_at(ser, "AT+CEREG=1")
    # Wait for LTE registration
    while True:
        out = send_at(ser, "AT+CEREG?", timeout=2)
        if re.search(r"\+CEREG: [0-9],[15]", out):
            break
        time.sleep(1)
    send_at(ser, "AT+CGATT=1")
    send_at(ser, "AT+QIACT=1")
    
    # MQTT open and connect
    send_at(ser, f'AT+QMTOPEN=0,"{BROKER}",1883')
    while True:
        line = ser.readline().decode(errors="ignore").strip()
        print(line)
        if "+QMTOPEN: 0,0" in line:
            break
    send_at(ser, 'AT+QMTCFG="keepalive",0,60')
    send_at(ser, f'AT+QMTCONN=0,"TestClient"')
    while True:
        line = ser.readline().decode(errors="ignore").strip()
        print(line)
        if "+QMTCONN: 0,0" in line:
            break
    
    # Publish only your payload
    send_at(ser, f'AT+QMTPUBEX=0,0,0,0,"{TOPIC}",{len(PAYLOAD)}', wait=">", timeout=5)
    ser.write(PAYLOAD.encode() + b"\x1A")
    ser.flush()
    while True:
        line = ser.readline().decode(errors="ignore").strip()
        if line:
            print(line)
        if "+QMTPUBEX: 0,0,0" in line:
            break

    # Close connection
    send_at(ser, "AT+QMTDISC=0")
    send_at(ser, "AT+QMTCLOSE=0")
